import React, { useState, useEffect } from 'react';
import { db, StoredOrder } from '../db/schema';
import { seedInitialDemoOrders } from '../db/demoSeeder';
import { liveQuery } from 'dexie';

export const AnalyticsView: React.FC = () => {
  const [orders, setOrders] = useState<StoredOrder[]>([]);
  const [nlQuery, setNlQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'ALL' | 'DUE' | 'UNPAID' | 'CAPACITY'>('ALL');

  useEffect(() => {
    const sub = liveQuery(() => db.orders.toArray()).subscribe({
      next: (val) => setOrders(val || [])
    });
    return () => sub.unsubscribe();
  }, []);

  const unpaidOrders = orders.filter((o: StoredOrder) => !o.is_deleted && !o.is_paid && (o.amount || 0) > 0);
  const totalReceivables = unpaidOrders.reduce((sum: number, o: StoredOrder) => sum + (o.amount || 0), 0);
  const dueTodayCount = orders.filter((o: StoredOrder) => !o.is_deleted && o.due_date === '2026-08-30').length;
  const overdueCount = orders.filter((o: StoredOrder) => !o.is_deleted && o.due_date && o.due_date < '2026-08-30').length;

  return (
    <div className="p-4 max-w-4xl mx-auto space-y-6">
      {/* Header & Seed Button */}
      <div className="flex justify-between items-center bg-slate-900/80 p-4 rounded-xl border border-slate-700">
        <div>
          <h2 className="text-xl font-bold text-white">Offline Operational Query Center</h2>
          <p className="text-xs text-slate-400">Instant answers with zero scrolling • 100% Offline IndexedDB</p>
        </div>
        <button
          onClick={async () => { await seedInitialDemoOrders(true); }}
          className="bg-emerald-600 hover:bg-emerald-500 text-white font-semibold px-4 py-2 rounded-lg text-sm transition shadow-lg flex items-center gap-2"
        >
          ⚡ Reset & Seed 20 Live Orders
        </button>
      </div>

      {/* 4 One-Click Objective 4 Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <button
          onClick={() => setActiveTab('DUE')}
          className={`p-3 rounded-xl border text-left transition ${activeTab === 'DUE' ? 'bg-amber-950/60 border-amber-500' : 'bg-slate-900/60 border-slate-800'}`}
        >
          <div className="text-xs text-slate-400">Due Today / Overdue</div>
          <div className="text-xl font-black text-amber-400 mt-1">{dueTodayCount} Due / {overdueCount} Late</div>
          <div className="text-[10px] text-slate-500 mt-1">Click to filter slips</div>
        </button>

        <button
          onClick={() => setActiveTab('UNPAID')}
          className={`p-3 rounded-xl border text-left transition ${activeTab === 'UNPAID' ? 'bg-emerald-950/60 border-emerald-500' : 'bg-slate-900/60 border-slate-800'}`}
        >
          <div className="text-xs text-slate-400">Total Receivables (Udhar)</div>
          <div className="text-xl font-black text-emerald-400 mt-1">₹{totalReceivables.toLocaleString()}</div>
          <div className="text-[10px] text-slate-500 mt-1">{unpaidOrders.length} customers owe money</div>
        </button>

        <button
          onClick={() => setActiveTab('CAPACITY')}
          className={`p-3 rounded-xl border text-left transition ${activeTab === 'CAPACITY' ? 'bg-indigo-950/60 border-indigo-500' : 'bg-slate-900/60 border-slate-800'}`}
        >
          <div className="text-xs text-slate-400">Committed Capacity</div>
          <div className="text-xl font-black text-indigo-400 mt-1">7-Day Heatmap</div>
          <div className="text-[10px] text-slate-500 mt-1">Aug 30 – Sep 05 load</div>
        </button>

        <button
          onClick={() => setActiveTab('ALL')}
          className={`p-3 rounded-xl border text-left transition ${activeTab === 'ALL' ? 'bg-blue-950/60 border-blue-500' : 'bg-slate-900/60 border-slate-800'}`}
        >
          <div className="text-xs text-slate-400">Total Active Orders</div>
          <div className="text-xl font-black text-blue-400 mt-1">{orders.filter((o: StoredOrder) => !o.is_deleted).length} Orders</div>
          <div className="text-[10px] text-slate-500 mt-1">Across 4 domains</div>
        </button>
      </div>

      {/* Natural Language Query Bar */}
      <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800 flex gap-2">
        <input
          type="text"
          value={nlQuery}
          onChange={(e) => setNlQuery(e.target.value)}
          placeholder="Ask offline query (e.g., 'who owes money', 'due today', 'sarita didi')..."
          className="bg-slate-950 border border-slate-700 text-white text-sm rounded-lg px-3 py-2 flex-1 focus:outline-none focus:border-emerald-500"
        />
        {nlQuery && (
          <button onClick={() => setNlQuery('')} className="text-xs text-slate-400 hover:text-white px-2">Clear</button>
        )}
      </div>

      {/* Unpaid Debtors Table with Instant Mark Paid Action */}
      {activeTab === 'UNPAID' && (
        <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-700">
          <h3 className="text-sm font-bold text-emerald-400 mb-3 uppercase tracking-wider">Customer Receivables Ledger</h3>
          <div className="divide-y divide-slate-800">
            {unpaidOrders.map((order: StoredOrder) => (
              <div key={order.id} className="py-2 flex justify-between items-center">
                <div>
                  <div className="text-sm font-semibold text-white">{order.customer || 'Unspecified Customer'}</div>
                  <div className="text-xs text-slate-400">{order.items.map(i => `${i.quantity}x ${i.description}`).join(', ')}</div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-sm font-bold text-amber-400">₹{order.amount}</span>
                  <button
                    onClick={async () => {
                      await db.orders.update(order.id, { is_paid: true, paid_at: new Date().toISOString() });
                    }}
                    className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs px-2.5 py-1.5 rounded font-medium transition"
                  >
                    ✓ Mark Paid
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
