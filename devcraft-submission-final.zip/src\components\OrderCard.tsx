import React from 'react';
import { StoredOrder } from '../db/schema';

interface OrderCardProps {
  order: StoredOrder;
  onMarkPaid?: (id: string, isPaid: boolean) => void;
  onStatusChange?: (id: string, status: any) => void;
  onDelete?: (id: string) => void;
}

export const OrderCard: React.FC<OrderCardProps> = ({
  order,
  onMarkPaid,
  onStatusChange,
  onDelete,
}) => {
  const isPaid = order.is_paid;
  const isNeedsClarify = order.needs_clarification || order.status === 'NEEDS_CLARIFICATION';

  return (
    <div className="bg-slate-900/90 border border-slate-800 hover:border-slate-700 rounded-2xl p-4 transition-all duration-200 shadow-lg flex flex-col justify-between gap-4">
      {/* Card Header: Customer Info & Status Badges */}
      <div className="flex justify-between items-start gap-2">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-slate-400 text-sm">👤</span>
            <h3 className="font-bold text-white text-base tracking-wide">
              {order.customer || 'Unspecified Customer'}
            </h3>
          </div>
          <p className="text-[11px] font-mono text-slate-500 mt-0.5">ID: {order.id}</p>
        </div>

        {/* Right Status Chips */}
        <div className="flex flex-wrap items-center justify-end gap-1.5">
          {order.amount && (
            <span
              className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${
                isPaid
                  ? 'bg-emerald-950/80 border-emerald-500/50 text-emerald-400'
                  : 'bg-amber-950/80 border-amber-500/50 text-amber-400'
              }`}
            >
              {isPaid ? 'PAID' : `UNPAID (₹${order.amount})`}
            </span>
          )}

          {isNeedsClarify && (
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-950/80 border border-rose-500/50 text-rose-400 animate-pulse">
              NEEDS CLARIFICATION
            </span>
          )}

          <span className="text-[10px] font-mono font-medium px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
            {order.status}
          </span>
        </div>
      </div>

      {/* Items Section */}
      <div className="bg-slate-950/70 rounded-xl p-3 border border-slate-800/80 space-y-2">
        {order.items.length === 0 ? (
          <p className="text-xs text-slate-500 italic">No structured items detected.</p>
        ) : (
          order.items.map((item, idx) => (
            <div key={idx} className="flex flex-col gap-1 text-sm">
              <div className="font-semibold text-slate-200">
                <span className="text-indigo-400 font-bold">{item.quantity}x</span> {item.description}
              </div>
              {item.attributes && Object.keys(item.attributes).length > 0 && (
                <div className="flex flex-wrap gap-1.5 mt-0.5">
                  {Object.entries(item.attributes).map(([k, v]) => (
                    <span
                      key={k}
                      className="text-[11px] bg-slate-900 border border-slate-700/80 text-slate-300 px-2 py-0.5 rounded-md"
                    >
                      <span className="text-slate-500">{k}:</span> {String(v)}
                    </span>
                  ))}
                </div>
              )}
            </div>
          ))
        )}
      </div>

      {/* Footer: Date, Amount & Action Buttons */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3 pt-1 border-t border-slate-800/60">
        <div className="flex items-center gap-4 text-xs font-medium text-slate-400">
          <div className="flex items-center gap-1.5">
            <span>📅</span>
            <span className={order.due_date ? 'text-slate-200 font-mono' : 'text-slate-500'}>
              {order.due_date || 'No deadline'}
            </span>
          </div>

          {order.amount && (
            <div className="text-amber-400 font-bold text-sm">
              ₹{order.amount.toLocaleString()}
            </div>
          )}
        </div>

        {/* Compact Action Buttons */}
        <div className="flex items-center gap-2">
          {onMarkPaid && order.amount && (
            <button
              onClick={() => onMarkPaid(order.id, !isPaid)}
              className={`text-xs px-3 py-1.5 rounded-lg font-semibold transition shadow-sm ${
                isPaid
                  ? 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
                  : 'bg-emerald-600 hover:bg-emerald-500 text-white'
              }`}
            >
              {isPaid ? 'Mark Unpaid' : '₹ Mark Paid'}
            </button>
          )}

          {onStatusChange && (
            <button
              onClick={() =>
                onStatusChange(order.id, order.status === 'DELIVERED' ? 'PENDING' : 'DELIVERED')
              }
              className="text-xs bg-indigo-600 hover:bg-indigo-500 text-white px-3 py-1.5 rounded-lg font-semibold transition shadow-sm"
            >
              {order.status === 'DELIVERED' ? 'Set Pending' : '✓ Delivered'}
            </button>
          )}

          {onDelete && (
            <button
              onClick={() => onDelete(order.id)}
              className="text-xs bg-rose-950/60 hover:bg-rose-900 border border-rose-800/80 text-rose-300 px-2.5 py-1.5 rounded-lg font-medium transition"
              title="Delete Order"
            >
              🗑️
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
