import React from 'react';
import { Tag } from 'lucide-react';
import { DomainType } from '../parser/types';

interface AttributeChipProps {
  attrKey: string;
  value: string | number | boolean;
  domain?: DomainType;
  index?: number;
}

const DOMAIN_GLOW_COLORS: Record<DomainType, { border: string; glow: string; text: string }> = {
  tailor: { border: '#6366f1', glow: 'rgba(99, 102, 241, 0.15)', text: '#a5b4fc' },
  baker: { border: '#f97316', glow: 'rgba(249, 115, 22, 0.15)', text: '#fdba74' },
  tiffin: { border: '#10b981', glow: 'rgba(16, 185, 129, 0.15)', text: '#6ee7b7' },
  electrician: { border: '#eab308', glow: 'rgba(234, 179, 8, 0.15)', text: '#fde047' }
};

export const AttributeChip: React.FC<AttributeChipProps> = ({ attrKey, value, domain = 'tailor', index = 0 }) => {
  const theme = DOMAIN_GLOW_COLORS[domain] || DOMAIN_GLOW_COLORS.tailor;

  return (
    <span
      className="attr-chip"
      style={{
        borderColor: theme.border,
        backgroundColor: theme.glow,
        color: theme.text,
        animationDelay: `${index * 30}ms`
      }}
    >
      <Tag size={10} style={{ display: 'inline', marginRight: '2px' }} />
      <span>
        {attrKey}: <strong>{String(value)}</strong>
      </span>
    </span>
  );
};
