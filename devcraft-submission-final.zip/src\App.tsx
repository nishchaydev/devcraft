import React, { useState, useEffect } from 'react';
import { IntakeView } from './views/IntakeView';
import { OrdersView } from './views/OrdersView';
import { ConflictView } from './views/ConflictView';
import { AnalyticsView } from './views/AnalyticsView';
import { BatchEvalView } from './views/BatchEvalView';
import { seedInitialDemoOrders } from './db/demoSeeder';
import { db } from './db/schema';
import { liveQuery } from 'dexie';

type Tab = 'intake' | 'orders' | 'conflicts' | 'analytics' | 'testA';

export const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>('intake');
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [conflictCount, setConflictCount] = useState<number>(0);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Initial silent check and seed if database is empty
    seedInitialDemoOrders(false);

    const sub = liveQuery(() => 
      db.conflicts.where('surfaced_to_operator').equals(1).count()
    ).subscribe({
      next: (count) => setConflictCount(count || 0)
    });

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      sub.unsubscribe();
    };
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* Top Navigation Bar */}
      <header className="sticky top-0 z-50 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 px-4 py-3 flex justify-between items-center shadow-lg">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center font-black text-white text-lg shadow-md shadow-indigo-500/30">
            D
          </div>
          <div>
            <h1 className="text-base font-bold text-white tracking-wide flex items-center gap-2">
              DevCraft OMS <span className="text-[10px] bg-indigo-900/80 text-indigo-300 px-2 py-0.5 rounded border border-indigo-700">v2.0 Glass</span>
            </h1>
            <p className="text-[11px] text-slate-400">Offline-First Micro-Business Engine</p>
          </div>
        </div>

        {/* Network & Engine Status Badges */}
        <div className="flex items-center gap-2">
          <span className={`text-xs px-2.5 py-1 rounded-full font-medium border flex items-center gap-1.5 shadow-sm ${
            isOnline 
              ? 'bg-emerald-950/70 border-emerald-500/40 text-emerald-400' 
              : 'bg-amber-950/70 border-amber-500/40 text-amber-400 animate-pulse'
          }`}>
            <span className={`w-2 h-2 rounded-full ${isOnline ? 'bg-emerald-400' : 'bg-amber-400'}`}></span>
            {isOnline ? 'ONLINE' : 'AIRPLANE MODE'}
          </span>
        </div>
      </header>

      {/* Main Viewport Container */}
      <main className="flex-1 pb-24 max-w-5xl w-full mx-auto p-4">
        {activeTab === 'intake' && <IntakeView/>}
        {activeTab === 'orders' && <OrdersView onNewOrderClick={() => setActiveTab('intake')}/>}
        {activeTab === 'conflicts' && <ConflictView/>}
        {activeTab === 'analytics' && <AnalyticsView/>}
        {activeTab === 'testA' && <BatchEvalView/>}
      </main>

      {/* Bottom Floating Navigation Dock */}
      <nav className="fixed bottom-3 left-1/2 -translate-x-1/2 z-50 bg-slate-900/90 backdrop-blur-md border border-slate-700/80 px-4 py-2 rounded-2xl flex items-center gap-2 shadow-2xl">
        <button
          onClick={() => setActiveTab('intake')}
          className={`flex items-center gap-1.5 py-1.5 px-3 rounded-xl text-xs font-semibold transition ${
            activeTab === 'intake'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <span>➕</span>
          <span>Intake</span>
        </button>

        <button
          onClick={() => setActiveTab('orders')}
          className={`flex items-center gap-1.5 py-1.5 px-3 rounded-xl text-xs font-semibold transition ${
            activeTab === 'orders'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <span>📋</span>
          <span>Orders</span>
        </button>

        <button
          onClick={() => setActiveTab('conflicts')}
          className={`flex items-center gap-1.5 py-1.5 px-3 rounded-xl text-xs font-semibold transition relative ${
            activeTab === 'conflicts'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <span>⚡</span>
          <span>Conflicts</span>
          {conflictCount > 0 && (
            <span className="w-4 h-4 bg-amber-500 text-slate-950 text-[10px] font-black rounded-full flex items-center justify-center">
              {conflictCount}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('analytics')}
          className={`flex items-center gap-1.5 py-1.5 px-3 rounded-xl text-xs font-semibold transition ${
            activeTab === 'analytics'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <span>📊</span>
          <span>Analytics</span>
        </button>

        <button
          onClick={() => setActiveTab('testA')}
          className={`flex items-center gap-1.5 py-1.5 px-3 rounded-xl text-xs font-semibold transition ${
            activeTab === 'testA'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <span>🧪</span>
          <span>Test A</span>
        </button>
      </nav>
    </div>
  );
};

export default App;
