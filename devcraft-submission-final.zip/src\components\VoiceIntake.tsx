import React, { useState, useEffect, useRef } from 'react';
import { Mic, MicOff, AlertCircle } from 'lucide-react';

interface VoiceIntakeProps {
  onTranscriptChange: (text: string) => void;
  onListeningComplete?: () => void;
  domainGlowColor?: string;
}

export const VoiceIntake: React.FC<VoiceIntakeProps> = ({
  onTranscriptChange,
  onListeningComplete,
  domainGlowColor = '#6366f1'
}) => {
  const [isListening, setIsListening] = useState(false);
  const [isSupported, setIsSupported] = useState(true);
  const [interimTranscript, setInterimTranscript] = useState('');
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setIsSupported(false);
      return;
    }

    const rec = new SpeechRecognition();
    rec.continuous = true;
    rec.interimResults = true;
    rec.lang = 'hi-IN';

    rec.onresult = (event: any) => {
      let finalTranscript = '';
      let currentInterim = '';

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcriptText = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          finalTranscript += transcriptText;
        } else {
          currentInterim += transcriptText;
        }
      }

      const activeText = finalTranscript || currentInterim;
      setInterimTranscript(currentInterim);
      if (activeText) {
        onTranscriptChange(activeText);
      }
    };

    rec.onerror = (event: any) => {
      console.warn('Speech Recognition Warning/Error:', event.error);
      setIsListening(false);
    };

    rec.onend = () => {
      setIsListening(false);
      if (onListeningComplete) {
        onListeningComplete();
      }
    };

    recognitionRef.current = rec;
  }, [onTranscriptChange, onListeningComplete]);

  const toggleListening = () => {
    if (!isSupported) return;

    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      if (onListeningComplete) onListeningComplete();
    } else {
      setInterimTranscript('');
      try {
        recognitionRef.current?.start();
        setIsListening(true);
      } catch (err) {
        console.error('Failed to start voice recognition:', err);
      }
    }
  };

  if (!isSupported) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.72rem', color: '#f59e0b', marginBottom: '8px' }}>
        <AlertCircle size={14} /> Voice intake API not available in this browser environment. Type order message below.
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '12px' }}>
      <button
        type="button"
        onClick={toggleListening}
        style={{
          backgroundColor: isListening ? '#dc2626' : '#312e81',
          color: '#ffffff',
          border: `1px solid ${isListening ? '#ef4444' : domainGlowColor}`,
          borderRadius: '50%',
          width: '52px',
          height: '52px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          boxShadow: isListening ? `0 0 20px ${domainGlowColor}` : '0 4px 12px rgba(0, 0, 0, 0.3)',
          cursor: 'pointer',
          flexShrink: 0
        }}
        title={isListening ? 'Click to stop voice intake' : 'Click to speak order in Hindi/Hinglish'}
      >
        {isListening ? <MicOff size={22} className="animate-pulse" /> : <Mic size={22} color={domainGlowColor} />}
      </button>

      {/* Animated 5-Bar Waveform */}
      {isListening ? (
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <div className="voice-waveform">
            {[1, 2, 3, 4, 5].map(barIdx => (
              <div
                key={barIdx}
                className="voice-waveform-bar"
                style={{ backgroundColor: domainGlowColor }}
              />
            ))}
          </div>
          <span style={{ fontSize: '0.78rem', color: '#38bdf8', fontWeight: 700 }}>
            Listening... {interimTranscript && `"${interimTranscript.slice(-25)}"`}
          </span>
        </div>
      ) : (
        <span style={{ fontSize: '0.78rem', color: '#94a3b8' }}>
          Tap mic to dictate in Hindi / Hinglish (e.g. <em>"2 kurta navy blue..."</em>)
        </span>
      )}
    </div>
  );
};
