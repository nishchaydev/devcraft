import { db, StoredOrder } from '../db/schema';
import { formatDateUTC } from '../parser/dateResolver';

export interface CustomerBalance {
  customer: string;
  totalUnpaid: number;
  orderCount: number;
  latestDueDate: string | null;
  orderIds: string[];
}

export interface CapacitySummary {
  totalOrders: number;
  totalItems: number;
  itemCountsByDescription: Record<string, number>;
  ordersByDate: Record<string, number>;
}

export interface HeatmapDayInfo {
  dateStr: string;
  count: number;
  totalItems: number;
  domains: string[];
}

export class QueryEngine {
  /**
   * Get orders due today and overdue orders using indexed Dexie queries
   */
  public static async getDueOrders(referenceDate?: string): Promise<{ overdue: StoredOrder[]; dueToday: StoredOrder[]; upcoming: StoredOrder[] }> {
    const todayStr = referenceDate || formatDateUTC(new Date());

    const dueOrOverdue = await db.orders
      .where('due_date')
      .belowOrEqual(todayStr)
      .filter(o => !o.is_deleted)
      .toArray();

    const upcomingOrders = await db.orders
      .where('due_date')
      .above(todayStr)
      .filter(o => !o.is_deleted)
      .toArray();

    const overdue: StoredOrder[] = [];
    const dueToday: StoredOrder[] = [];

    for (const order of dueOrOverdue) {
      if (order.due_date === todayStr) {
        dueToday.push(order);
      } else {
        overdue.push(order);
      }
    }

    return { overdue, dueToday, upcoming: upcomingOrders };
  }

  /**
   * Get customers who owe money with aggregated total receivables (strictly is_paid === false)
   */
  public static async getUnpaidBalances(): Promise<{ totalReceivables: number; customerLedger: CustomerBalance[] }> {
    const unpaidOrders = await db.orders
      .filter(o => !o.is_deleted && !o.is_paid && o.amount !== null && o.amount > 0)
      .toArray();

    const ledgerMap = new Map<string, { total: number; count: number; maxDate: string | null; ids: string[] }>();
    let grandTotal = 0;

    for (const order of unpaidOrders) {
      const cust = order.customer || 'Unspecified Customer';
      const amt = order.amount || 0;
      grandTotal += amt;

      const existing = ledgerMap.get(cust) || { total: 0, count: 0, maxDate: null, ids: [] };
      existing.total += amt;
      existing.count += 1;
      existing.ids.push(order.id);
      if (order.due_date && (!existing.maxDate || order.due_date > existing.maxDate)) {
        existing.maxDate = order.due_date;
      }
      ledgerMap.set(cust, existing);
    }

    const customerLedger: CustomerBalance[] = Array.from(ledgerMap.entries()).map(([cust, data]) => ({
      customer: cust,
      totalUnpaid: data.total,
      orderCount: data.count,
      latestDueDate: data.maxDate,
      orderIds: data.ids
    })).sort((a, b) => b.totalUnpaid - a.totalUnpaid);

    return { totalReceivables: grandTotal, customerLedger };
  }

  /**
   * Get workload density heatmap data for the next 28 days (4 weeks)
   */
  public static async getWorkloadHeatmap(weeks = 4): Promise<HeatmapDayInfo[]> {
    const today = new Date();
    const result: HeatmapDayInfo[] = [];
    const numDays = weeks * 7;

    const allActiveOrders = await db.orders
      .filter(o => !o.is_deleted && Boolean(o.due_date))
      .toArray();

    const dateMap = new Map<string, { count: number; items: number; domains: Set<string> }>();

    for (const order of allActiveOrders) {
      if (!order.due_date) continue;
      const existing = dateMap.get(order.due_date) || { count: 0, items: 0, domains: new Set<string>() };
      existing.count += 1;

      const itemCount = (order.items || []).reduce((acc, it) => acc + (it.quantity || 1), 0);
      existing.items += itemCount;

      if ((order as any).detectedDomain) {
        existing.domains.add((order as any).detectedDomain);
      }
      dateMap.set(order.due_date, existing);
    }

    for (let i = 0; i < numDays; i++) {
      const d = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate() + i));
      const dateStr = formatDateUTC(d);
      const data = dateMap.get(dateStr);

      result.push({
        dateStr,
        count: data ? data.count : 0,
        totalItems: data ? data.items : 0,
        domains: data ? Array.from(data.domains) : []
      });
    }

    return result;
  }

  /**
   * Get past orders and specifications for a specific customer ("last time jaisa")
   */
  public static async getCustomerHistory(customerName: string): Promise<StoredOrder[]> {
    if (!customerName || customerName.trim() === '') return [];
    const search = customerName.toLowerCase().trim();

    const orders = await db.orders
      .filter(o => !o.is_deleted && o.customer !== null && o.customer.toLowerCase().includes(search))
      .toArray();

    return orders.sort((a, b) => b.updated_at.localeCompare(a.updated_at));
  }

  /**
   * Get committed capacity and item tallies for a date range (e.g. current week)
   */
  public static async getCommittedCapacity(startDateStr?: string, endDateStr?: string): Promise<CapacitySummary> {
    const allOrders = await db.orders.filter(o => !o.is_deleted && o.due_date !== null).toArray();

    const filtered = allOrders.filter(o => {
      if (!o.due_date) return false;
      if (startDateStr && o.due_date < startDateStr) return false;
      if (endDateStr && o.due_date > endDateStr) return false;
      return true;
    });

    let totalItemsCount = 0;
    const itemCounts: Record<string, number> = {};
    const ordersByDate: Record<string, number> = {};

    for (const order of filtered) {
      if (order.due_date) {
        ordersByDate[order.due_date] = (ordersByDate[order.due_date] || 0) + 1;
      }

      for (const item of order.items || []) {
        const desc = item.description || 'unnamed item';
        const qty = item.quantity || 1;
        totalItemsCount += qty;
        itemCounts[desc] = (itemCounts[desc] || 0) + qty;
      }
    }

    return {
      totalOrders: filtered.length,
      totalItems: totalItemsCount,
      itemCountsByDescription: itemCounts,
      ordersByDate
    };
  }
}
