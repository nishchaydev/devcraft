import React, { useState } from 'react';
import { DomainType, OrderRecord, InputRecord } from '../parser/types';
import { parseMessageRecord } from '../parser/hybridParser';
import { db, StoredOrder } from '../db/schema';
import { Sparkles, CheckCircle2, MessageSquare, Send, Code, Cpu, Calendar, DollarSign, User, Scissors, Utensils, Zap, Cake, Copy, Check } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { AttributeChip } from '../components/AttributeChip';
import { VoiceIntake } from '../components/VoiceIntake';

const DOMAIN_ICONS: Record<DomainType, React.ReactNode> = {
  tailor: <Scissors size={14} color="#a5b4fc" />,
  tiffin: <Utensils size={14} color="#fef08a" />,
  electrician: <Zap size={14} color="#6ee7b7" />,
  baker: <Cake size={14} color="#fbcfe8" />
};

const DOMAIN_LABELS: Record<DomainType, string> = {
  tailor: 'Tailor (Auto-Detected)',
  tiffin: 'Tiffin (Auto-Detected)',
  electrician: 'Electrician (Auto-Detected)',
  baker: 'Baker (Auto-Detected)'
};

const DOMAIN_ACCENT_COLORS: Record<DomainType, string> = {
  tailor: '#818cf8',
  tiffin: '#34d399',
  electrician: '#facc15',
  baker: '#fb923c'
};

const INITIAL_SAMPLE = "bhaiya 2 kurta chahiye navy blue, chest 40, parso tak ho jayega kya? last time jaisa hi";

export const IntakeView: React.FC<{ onOrderCreated?: () => void }> = ({ onOrderCreated }) => {
  const { t } = useLanguage();
  const [message, setMessage] = useState(INITIAL_SAMPLE);
  const [isParsing, setIsParsing] = useState(false);
  const [parsedRecord, setParsedRecord] = useState<OrderRecord | null>(null);
  const [successMsg, setSuccessMsg] = useState('');
  const [showInspector, setShowInspector] = useState(false);
  const [copied, setCopied] = useState(false);

  // 3D Tilt State
  const [tiltStyle, setTiltStyle] = useState<React.CSSProperties>({});

  const handleParseText = async (textToParse: string) => {
    if (!textToParse.trim()) return;
    setIsParsing(true);
    setSuccessMsg('');
    setCopied(false);

    const inputRec: InputRecord = {
      id: `order-${Date.now()}`,
      received_at: new Date().toISOString(),
      message: textToParse.trim()
    };

    const result = await parseMessageRecord(inputRec);
    setParsedRecord(result);
    setIsParsing(false);
  };

  const handleParse = () => {
    handleParseText(message);
  };

  const handleVoiceTranscriptChange = (newTranscript: string) => {
    setMessage(newTranscript);
  };

  const handleVoiceListeningComplete = () => {
    if (message.trim()) {
      handleParseText(message);
    }
  };

  const handleSaveOrder = async () => {
    if (!parsedRecord) return;

    const orderId = `ORD-${Math.floor(1000 + Math.random() * 9000)}`;
    const stored: StoredOrder = {
      id: orderId,
      ...parsedRecord,
      status: parsedRecord.needs_clarification ? 'NEEDS_CLARIFICATION' : 'SYNCED',
      device_id: 'local_device',
      updated_at: new Date().toISOString()
    };

    await db.orders.put(stored);
    setSuccessMsg(`Order ${orderId} saved to IndexedDB!`);
    setParsedRecord(null);
    if (onOrderCreated) onOrderCreated();
  };

  const handleOpenWhatsApp = () => {
    if (!parsedRecord?.whatsappReply) return;
    const encoded = encodeURIComponent(parsedRecord.whatsappReply);
    window.open(`https://wa.me/?text=${encoded}`, '_blank');
  };

  const handleCopyReply = () => {
    if (!parsedRecord?.whatsappReply) return;
    navigator.clipboard.writeText(parsedRecord.whatsappReply);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // 3D Card Hover Interaction
  const handleMouseMoveCard = (e: React.MouseEvent<HTMLDivElement>) => {
    const card = e.currentTarget;
    const rect = card.getBoundingClientRect();
    const x = e.clientX - rect.left - rect.width / 2;
    const y = e.clientY - rect.top - rect.height / 2;

    const rotateX = (y / (rect.height / 2)) * -6;
    const rotateY = (x / (rect.width / 2)) * 6;

    setTiltStyle({
      transform: `perspective(1000px) rotateX(${rotateX.toFixed(2)}deg) rotateY(${rotateY.toFixed(2)}deg) scale3d(1.01, 1.01, 1.01)`
    });
  };

  const handleMouseLeaveCard = () => {
    setTiltStyle({
      transform: 'perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)'
    });
  };

  const currentGlowColor = parsedRecord?.detectedDomain ? DOMAIN_ACCENT_COLORS[parsedRecord.detectedDomain] : '#6366f1';

  return (
    <div style={{ padding: '16px' }} className="animate-fade-in">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
        <h2 style={{ fontSize: '1.25rem', fontWeight: 700, color: '#f8fafc' }}>
          Unified Order Intake & Parser
        </h2>
      </div>

      {/* Voice Assistant & WhatsApp Chat Style Input Card */}
      <div className="card-glass" style={{ padding: '16px', marginBottom: '16px', borderColor: currentGlowColor }}>
        <VoiceIntake
          onTranscriptChange={handleVoiceTranscriptChange}
          onListeningComplete={handleVoiceListeningComplete}
          domainGlowColor={currentGlowColor}
        />

        <div style={{ backgroundColor: '#064e3b', padding: '12px', borderRadius: '12px 12px 12px 2px', borderLeft: `4px solid ${currentGlowColor}`, marginBottom: '12px' }}>
          <textarea
            rows={3}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            style={{
              width: '100%',
              backgroundColor: 'transparent',
              border: 'none',
              color: '#f8fafc',
              fontSize: '0.95rem',
              resize: 'vertical',
              outline: 'none',
              fontFamily: 'inherit'
            }}
            placeholder="Type or speak customer order message in Hindi/Hinglish (Tailor, Tiffin, Electrician, Baker)..."
          />
        </div>

        <button onClick={handleParse} disabled={isParsing} className="btn-primary" style={{ backgroundColor: currentGlowColor }}>
          <Sparkles size={18} />
          <span>{isParsing ? 'Parsing & Auto-Detecting Operator...' : t('parseBtn')}</span>
        </button>
      </div>

      {/* Parsed Smart-Card with 3D Tilt Effect & Auto-Detected Operator Badge */}
      {parsedRecord && (
        <div className="card-tilt-wrapper" style={{ marginBottom: '16px' }}>
          <div
            className="card-glass card-tilt-inner animate-card-enter"
            onMouseMove={handleMouseMoveCard}
            onMouseLeave={handleMouseLeaveCard}
            style={{ padding: '16px', borderColor: currentGlowColor, ...tiltStyle }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
              <h3 style={{ fontSize: '1rem', fontWeight: 700, color: '#34d399', display: 'flex', alignItems: 'center', gap: '6px' }}>
                <CheckCircle2 size={18} /> Parsed Order Smart-Card
              </h3>
              <span className={`badge ${parsedRecord.needs_clarification ? 'badge-clarify' : 'badge-synced'}`}>
                {parsedRecord.needs_clarification ? 'Needs Clarification' : 'Ready'}
              </span>
            </div>

            {/* Operator Auto-Detection Badge with Pop-In Animation */}
            <div style={{ display: 'flex', gap: '8px', marginBottom: '12px', flexWrap: 'wrap' }}>
              {parsedRecord.detectedDomain && (
                <span className="badge attr-chip" style={{ backgroundColor: '#1e1b4b', color: currentGlowColor, border: `1px solid ${currentGlowColor}`, fontSize: '0.75rem' }}>
                  {DOMAIN_ICONS[parsedRecord.detectedDomain]}
                  <span style={{ fontWeight: 700 }}>{DOMAIN_LABELS[parsedRecord.detectedDomain]}</span>
                </span>
              )}
              <span className="badge" style={{ backgroundColor: '#1e3a8a', color: '#60a5fa', border: '1px solid #2563eb' }}>
                <Cpu size={12} /> {parsedRecord.engineUsed === 'gemini-flash' ? 'Gemini 1.5 Flash API (Online)' : 'Local Fast-NLP Engine (Offline)'}
              </span>
              <span className="badge" style={{ backgroundColor: '#020617', color: '#a7f3d0', border: '1px solid #059669' }}>
                ⚡ {parsedRecord.latencyMs}ms | {(parsedRecord.confidence * 100).toFixed(0)}% Confidence
              </span>
            </div>

            <div style={{ backgroundColor: 'rgba(15, 23, 42, 0.7)', padding: '12px', borderRadius: '8px', marginBottom: '12px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
                <User size={16} color="#94a3b8" />
                <span style={{ fontWeight: 700, color: '#f8fafc' }}>
                  Customer: {parsedRecord.customer || 'Unspecified'}
                </span>
              </div>

              <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', marginBottom: '8px' }}>
                {parsedRecord.due_date && (
                  <span className="badge" style={{ backgroundColor: '#312e81', color: '#a5b4fc', border: '1px solid #4338ca' }}>
                    <Calendar size={12} /> Due: {parsedRecord.due_date}
                  </span>
                )}
                {parsedRecord.amount !== null && (
                  <span className="badge" style={{ backgroundColor: '#064e3b', color: '#6ee7b7', border: '1px solid #047857' }}>
                    <DollarSign size={12} /> ₹{parsedRecord.amount}
                  </span>
                )}
                {parsedRecord.references_prior_order && (
                  <span className="badge" style={{ backgroundColor: '#451a03', color: '#fde68a', border: '1px solid #b45309' }}>
                    Repeat Order ("last time jaisa")
                  </span>
                )}
              </div>

              {parsedRecord.items.map((it, idx) => (
                <div key={idx} style={{ borderTop: '1px solid rgba(51, 65, 85, 0.5)', paddingTop: '6px', marginTop: '6px' }}>
                  <span style={{ fontWeight: 700, color: '#e2e8f0' }}>
                    {it.quantity}x {it.description}
                  </span>
                  <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', marginTop: '4px' }}>
                    {Object.entries(it.attributes).map(([k, v], aIdx) => (
                      <AttributeChip key={k} attrKey={k} value={v} domain={parsedRecord.detectedDomain} index={aIdx} />
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* Formatted Dark Mode WhatsApp Bubble with One-Click Copy Button */}
            {parsedRecord.whatsappReply && (
              <div className="whatsapp-bubble" style={{ marginBottom: '12px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                  <span style={{ fontSize: '0.72rem', color: '#a7f3d0', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '4px' }}>
                    <MessageSquare size={12} /> AUTOMATIC WHATSAPP CONFIRMATION REPLY:
                  </span>
                  <button
                    onClick={handleCopyReply}
                    style={{
                      backgroundColor: '#128c7e',
                      color: '#ffffff',
                      border: 'none',
                      padding: '2px 8px',
                      fontSize: '0.7rem',
                      borderRadius: '4px',
                      minHeight: '24px',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '4px',
                      cursor: 'pointer'
                    }}
                  >
                    {copied ? <Check size={12} /> : <Copy size={12} />}
                    <span>{copied ? 'Copied!' : 'Copy Reply'}</span>
                  </button>
                </div>
                <p style={{ fontSize: '0.85rem', color: '#f8fafc', fontStyle: 'italic', marginBottom: '8px', lineHeight: 1.4 }}>
                  "{parsedRecord.whatsappReply}"
                </p>
                <button onClick={handleOpenWhatsApp} className="btn-primary" style={{ backgroundColor: '#25d366', minHeight: '36px', fontSize: '0.85rem', color: '#0f172a', fontWeight: 800 }}>
                  <Send size={14} /> Send WhatsApp Reply
                </button>
              </div>
            )}

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
              <button onClick={() => setShowInspector(!showInspector)} className="btn-secondary" style={{ minHeight: '40px', fontSize: '0.85rem' }}>
                <Code size={14} /> {showInspector ? 'Hide AI Inspector' : 'View AI Breakdown'}
              </button>
              <button onClick={handleSaveOrder} className="btn-primary" style={{ backgroundColor: '#10b981', minHeight: '40px', fontSize: '0.85rem' }}>
                {t('confirmSave')}
              </button>
            </div>

            {showInspector && (
              <div className="animate-fade-in" style={{ backgroundColor: '#020617', padding: '12px', borderRadius: '8px', marginTop: '12px', border: '1px solid #334155' }}>
                <h4 style={{ fontSize: '0.85rem', fontWeight: 700, color: '#818cf8', marginBottom: '6px' }}>
                  AI Extraction & Normative Rule Breakdown
                </h4>
                <p style={{ fontSize: '0.75rem', color: '#94a3b8', marginBottom: '8px' }}>
                  {parsedRecord.ruleExplanation}
                </p>
                <span style={{ fontSize: '0.75rem', color: '#64748b', fontWeight: 700 }}>RAW SCHEMA.JSON OUTPUT:</span>
                <pre style={{ fontSize: '0.75rem', color: '#34d399', backgroundColor: '#0f172a', padding: '8px', borderRadius: '6px', overflowX: 'auto', marginTop: '4px' }}>
                  {JSON.stringify(parsedRecord, null, 2)}
                </pre>
              </div>
            )}
          </div>
        </div>
      )}

      {successMsg && (
        <div className="card animate-fade-in" style={{ backgroundColor: '#064e3b', borderColor: '#059669', color: '#34d399', fontWeight: 600, marginTop: '12px' }}>
          {successMsg}
        </div>
      )}
    </div>
  );
};
