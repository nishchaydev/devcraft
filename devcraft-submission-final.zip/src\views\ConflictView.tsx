import React, { useState } from 'react';
import { runAllScenarios, SimulationScenarioResult } from '../sync/simulator';

export const ConflictView: React.FC = () => {
  const [results, setResults] = useState<SimulationScenarioResult[]>([]);
  const [activeScenario, setActiveScenario] = useState<number>(1);

  const handleRunSim = () => {
    const res = runAllScenarios();
    setResults(res);
  };

  return (
    <div className="p-4 max-w-4xl mx-auto space-y-6">
      <div className="bg-slate-900/80 p-5 rounded-xl border border-slate-700">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h2 className="text-xl font-bold text-white">Deterministic Multi-Device Sync Center</h2>
            <p className="text-xs text-slate-400">Mathematical proof that Sync(A → B) ≡ Sync(B → A) under Lamport LWW</p>
          </div>
          <button
            onClick={handleRunSim}
            className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold px-4 py-2 rounded-lg text-sm shadow-lg transition"
          >
            ▶ Run Simulation Suite (Scenarios 1, 2, 3)
          </button>
        </div>

        {/* Dynamic SVG Visualizer */}
        <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 flex justify-center mb-4">
          <svg viewBox="0 0 400 120" className="w-full max-w-md">
            <circle cx="60" cy="60" r="30" fill="#0369a1" stroke="#38bdf8" strokeWidth="2" />
            <text x="60" y="65" fill="#fff" fontSize="12" textAnchor="middle" fontWeight="bold">Device A</text>

            <path d="M 95 50 L 305 50" stroke="#f59e0b" strokeWidth="2" strokeDasharray="4 4" />
            <path d="M 305 70 L 95 70" stroke="#10b981" strokeWidth="2" />

            <circle cx="340" cy="60" r="30" fill="#4338ca" stroke="#818cf8" strokeWidth="2" />
            <text x="340" y="65" fill="#fff" fontSize="12" textAnchor="middle" fontWeight="bold">Device B</text>
          </svg>
        </div>

        {/* Scenario Selection Tabs */}
        <div className="grid grid-cols-3 gap-2 mb-4">
          {[1, 2, 3].map(num => (
            <button
              key={num}
              onClick={() => setActiveScenario(num)}
              className={`py-2 text-xs font-bold rounded-lg border transition ${activeScenario === num ? 'bg-indigo-900/60 border-indigo-400 text-white' : 'bg-slate-900 border-slate-800 text-slate-400'}`}
            >
              Scenario {num}
            </button>
          ))}
        </div>

        {results.length > 0 && (
          <div className="space-y-4">
            {results.filter(r => r.scenarioNumber === activeScenario).map(res => (
              <div key={res.scenarioNumber} className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-bold text-white">{res.title}</span>
                  <span className="bg-emerald-950 border border-emerald-500 text-emerald-400 text-xs px-2.5 py-1 rounded font-mono">
                    Deterministic Invariance: PASS ✅
                  </span>
                </div>
                <div className="text-xs text-slate-400 font-mono bg-slate-900 p-3 rounded border border-slate-800">
                  State Hash (A→B): <span className="text-emerald-400 font-bold">{res.hashA}</span><br />
                  State Hash (B→A): <span className="text-emerald-400 font-bold">{res.hashB}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
